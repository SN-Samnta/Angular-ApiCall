export interface Abc{
    id: number;
    uid: number;
    hex_value: string;
    colorname: string;
    hslvalue: Array<number>;
    hslavalue: Array<number>;
}